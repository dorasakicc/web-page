const express = require("express");
const app = express();


app.use(function (req, res, next) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader(
    "Access-Control-Allow-Methods",
    "GET, POST, OPTIONS, PUT, PATCH, DELETE"
  );
  res.setHeader(
    "Access-Control-Allow-Headers",
    "X-Requested-With,content-type"
  );
  res.setHeader("Access-Control-Allow-Credentials", true);
  next();
});


const body_parser = require("body-parser");
app.use(body_parser.json());


// Učitavanje podataka iz datoteke
let korisnici = require('./users');




// GET zahtjev za dohvaćanje korisnika
app.get("/users", (req, res) => {
  res.send(korisnici);
});



// POST zahtjev za provjeru unosa
app.post('/users', (req, res) => {
  const { korisnik, lozinka } = req.body;

  // Provjera korisnika
  const user = korisnici.find(u => u.korisnik === korisnik && u.lozinka === lozinka);

  if (user) {
    res.status(200).json({ success: true, message: 'Login successful' });
    console.log("Uspješno ste se prijavili.");
  } else {
    res.status(401).json({ success: false, message: 'Krivo korisničko ime ili lozinka' });
    console.log("Krivo korisničko ime ili lozinka.");
  }
});

// Osluškuje konekcije za zadanom portu
app.listen(4000, () => console.log("Server sluša port 4000!"));
