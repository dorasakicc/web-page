module.exports = [
    {
       
        korisnik: "iva",
        lozinka: "ivic"
    },
    {
        
        korisnik: "ana",
        lozinka: "anic"
    },
    {
        
        korisnik: "toma",
        lozinka: "tomic"
    },
    {
        
        korisnik: "petra",
        lozinka: "petric"
    },
   
   
];