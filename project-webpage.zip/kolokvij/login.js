document.getElementById("prijava").addEventListener('click', async (e) => {
    e.preventDefault();

    let ime = document.getElementById('username').value;
    let lozinka = document.getElementById('password').value;
    
   
    let NoviPodatak = {
       
        korisnik: ime,
        lozinka: lozinka
    };

    let p = {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(NoviPodatak)
    };

    
    try {
        const res = await fetch('http://localhost:4000/users', p);
        const data = await res.json();

        let poruka = document.getElementById("message");
        if (res.status === 200 && data.success) {
            poruka.textContent = "Prijava uspješna! Preusmjeravanje ...";
            poruka.style.color = "green";
            window.location.href = 'dora.html';
           
        } else {
            poruka.textContent = data.message || "Neispravno korisničko ime ili lozinka.";
            poruka.style.color = "red";
        }
    } catch (error) {
        console.error('Error:', error);
        let poruka = document.getElementById("message");
        poruka.textContent = "Greška u prijavi!";
        poruka.style.color = "red";
    }
});
